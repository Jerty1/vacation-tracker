@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Запуск учебной экспертной системы ТурЭксперт...
echo Адрес в браузере: http://127.0.0.1:8765
py app.py
if errorlevel 1 (
 echo Не удалось запустить команду py. Проверьте Python 3.10+.
 pause
)
