#!/bin/sh
cd "$(dirname "$0")"
echo "Откройте http://127.0.0.1:8765"
python3 app.py
