"""Проверки сценариев и инвариантов учебной ЭС (unittest)."""
import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app

class ExpertSystemTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):app.initialize()
    def test_counts_and_knowledge(self):
        ds, qs, pr = app.knowledge()
        self.assertEqual(len(ds),25)
        self.assertEqual(len(qs),24)
        self.assertEqual(len(pr),4)
        self.assertGreaterEqual(min(len(d)-2 for d in ds),20)
        self.assertEqual(len(set(q['id'] for q in qs)),24)
    def test_auto_inference(self):
        sid=app.start_session()
        state=app.put_answer(sid,'purpose','beach')
        self.assertEqual(state['answers']['sea']['value'],'yes')
        self.assertEqual(state['answers']['sea']['origin'],'rule')
        self.assertEqual(state['next_question']['id'],'budget')
        self.assertEqual(len(state['top5']),5)
    def test_full_cycle(self):
        sid=app.start_session()
        preferences={'purpose':'beach','budget':'2','trip_length':'3','climate':'tropical','sea':'yes','culture':'1','nature':'3','active':'3','nightlife':'2','company':'family','max_distance':'3','cheap_priority':'3','long_trip_readiness':'3','romantic':'no','calm':'3','entertainment':'2','family':'3','city_size':'1','popularity':'1','unusual_climate':'yes','landmarks':'1','cuisine':'2','accessibility':'1','mountains':'2'}
        state=app.get_state(sid)
        while not state['finished']:
            q=state['next_question']
            state=app.put_answer(sid,q['id'],preferences[q['id']])
            self.assertEqual(len(state['top5']),5)
            self.assertGreaterEqual(len(state['answers']),1)
        self.assertEqual(len(state['all_results']),25)
        self.assertGreaterEqual(state['answered_by_user'],20)
        self.assertEqual(state['answered'],24)
        self.assertEqual([r['rank'] for r in state['all_results']],list(range(1,26)))
        self.assertEqual([x['score'] for x in state['all_results']],sorted([x['score'] for x in state['all_results']],reverse=True))
        self.assertTrue(all(x['reasons'] for x in state['all_results']))
    def test_parameter_rule_for_family(self):
        sid=app.start_session()
        state=app.put_answer(sid,'purpose','culture')
        for value in ['2','3','moderate','no','3','1','1','2']:
            q=state['next_question']
            self.assertIsNotNone(q)
            state=app.put_answer(sid,q['id'],value)
        self.assertEqual(state['next_question']['id'],'company')
        state=app.put_answer(sid,'company','family')
        self.assertEqual(state['answers']['family']['origin'],'rule')
        self.assertEqual(state['answers']['family']['value'],'3')
    def test_invalid_answer(self):
        sid=app.start_session()
        with self.assertRaises(ValueError):app.put_answer(sid,'purpose','unknown')
        with self.assertRaises(ValueError):app.put_answer(sid,'budget','2')
    def test_db_inspection(self):
        self.assertEqual(app.inspect('destinations')['count'],25)
        self.assertEqual(app.inspect('questions')['count'],24)
        with self.assertRaises(ValueError):app.inspect('sqlite_master')

if __name__=='__main__':unittest.main()
