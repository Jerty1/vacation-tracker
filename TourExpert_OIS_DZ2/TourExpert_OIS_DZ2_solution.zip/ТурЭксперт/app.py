"""Автономная учебная экспертная система выбора туристического направления.
Запуск: python app.py   Требования: Python 3.10+ (только стандартная библиотека).
"""
import json
import sqlite3
import secrets
from datetime import datetime, timezone
from functools import lru_cache
from contextlib import contextmanager
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

BASE = Path(__file__).resolve().parent
DATA = BASE / 'data'
STATIC = BASE / 'static'
KB_PATH = DATA / 'knowledge.db'
WORK_PATH = DATA / 'working.db'
HOST='127.0.0.1'
PORT=8765

@contextmanager
def connection(path):
    con=sqlite3.connect(path)
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

@lru_cache(maxsize=1)
def knowledge():
    with connection(KB_PATH) as con:
        ds=[json.loads(r[0]) for r in con.execute('SELECT payload FROM destinations ORDER BY id')]
        qs=[json.loads(r[0]) for r in con.execute('SELECT payload FROM questions ORDER BY position')]
        pr=[json.loads(r[0]) for r in con.execute('SELECT payload FROM parameter_rules ORDER BY id')]
    return ds, qs, pr

def initialize():
    DATA.mkdir(exist_ok=True)
    ds=json.loads((DATA/'destinations.json').read_text(encoding='utf-8'))
    obj=json.loads((DATA/'knowledge_rules.json').read_text(encoding='utf-8'))
    questions=obj['questions']
    if len(ds)<20 or len(questions)<20: raise ValueError('Недостаточно объектов или вопросов')
    if len(obj['feature_names'])<10: raise ValueError('Недостаточно атрибутов')
    with connection(KB_PATH) as con:
        con.executescript('''CREATE TABLE IF NOT EXISTS destinations(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS questions(id TEXT PRIMARY KEY, position INTEGER NOT NULL UNIQUE, payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS parameter_rules(id INTEGER PRIMARY KEY, payload TEXT NOT NULL);''')
        if con.execute('SELECT COUNT(*) FROM destinations').fetchone()[0] != len(ds):
            con.execute('DELETE FROM destinations');con.executemany('INSERT INTO destinations(id,name,payload) VALUES(?,?,?)',[(i+1,d['name'],json.dumps(d,ensure_ascii=False)) for i,d in enumerate(ds)])
        if con.execute('SELECT COUNT(*) FROM questions').fetchone()[0] != len(questions):
            con.execute('DELETE FROM questions');con.executemany('INSERT INTO questions(id,position,payload) VALUES(?,?,?)',[(q['id'],i,json.dumps(q,ensure_ascii=False)) for i,q in enumerate(questions)])
        if con.execute('SELECT COUNT(*) FROM parameter_rules').fetchone()[0] != len(obj['parameter_rules']):
            con.execute('DELETE FROM parameter_rules');con.executemany('INSERT INTO parameter_rules(id,payload) VALUES(?,?)',[(i+1,json.dumps(r,ensure_ascii=False)) for i,r in enumerate(obj['parameter_rules'])])
    with connection(WORK_PATH) as con:
        con.executescript('''PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS answers(session_id TEXT NOT NULL, param_id TEXT NOT NULL, value TEXT NOT NULL, origin TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(session_id,param_id), FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE);
        CREATE INDEX IF NOT EXISTS idx_answers_session ON answers(session_id);''')
    knowledge.cache_clear()

def ts():return datetime.now(timezone.utc).isoformat(timespec='seconds')

def start_session():
    sid=secrets.token_hex(16);now=ts()
    with connection(WORK_PATH) as con:con.execute('INSERT INTO sessions VALUES(?,?,?)',(sid,now,now))
    return sid

def get_answers(sid):
    with connection(WORK_PATH) as con:
        found=con.execute('SELECT 1 FROM sessions WHERE id=?',(sid,)).fetchone()
        if not found:raise ValueError('Сессия не найдена. Начните новый опрос.')
        rows=con.execute('SELECT param_id,value,origin FROM answers WHERE session_id=?',(sid,)).fetchall()
    return {r[0]:{'value':r[1],'origin':r[2]} for r in rows}

def next_question(answers,questions):
    return next((q for q in questions if q['id'] not in answers),None)

def put_answer(sid,qid,value):
    ds,qs,ps=knowledge();ans=get_answers(sid)
    q=next_question(ans,qs)
    if q is None:raise ValueError('Опрос уже завершён')
    if qid!=q['id']:raise ValueError('Ответ не на текущий вопрос')
    if value not in {str(o['value']) for o in q['options']}:raise ValueError('Недопустимое значение ответа')
    now=ts();updates={qid:(value,'user')}
    merged={k:v['value'] for k,v in ans.items()};merged[qid]=value
    # Вывод «параметр + параметр» — автоматическая установка только не заданных свойств.
    changed=True
    while changed:
        changed=False
        for rule in ps:
            if all(merged.get(k)==v for k,v in rule['if'].items()):
                for key,newvalue in rule['then'].items():
                    if key not in merged:
                        merged[key]=newvalue; updates[key]=(newvalue,'rule'); changed=True
    with connection(WORK_PATH) as con:
        con.execute('PRAGMA foreign_keys=ON')
        for k,(v,origin) in updates.items():
            con.execute('INSERT INTO answers(session_id,param_id,value,origin,created_at) VALUES(?,?,?,?,?)',(sid,k,v,origin,now))
        con.execute('UPDATE sessions SET updated_at=? WHERE id=?',(now,sid))
    return get_state(sid)

def partial_score(q,value,d):
    a=q['attribute'];w=q['weight'];v=str(value)
    if a=='styles':
        if v=='mixed':return (w*0.65 if len(d['styles'])>=3 else w*0.2)
        return w if v in d['styles'] else -0.35*w
    if q['id']=='company':
        # Формат поездки сопоставляется с семейной инфраструктурой, спокойствием и развлечениями.
        values={'solo':(d['entertainment']+d['accessibility'])/6,'couple':(d['romance']+d['calm'])/6,'friends':(d['nightlife']+d['entertainment'])/6,'family':d['family']/3}
        return w*values[v]
    if q['id']=='budget':
        diff=d['price']-int(v)
        return w*(0.75 if diff<=0 else -0.9*diff)
    if q['id']=='max_distance':
        diff=d['distance']-int(v)
        return w*(0.65 if diff<=0 else -1.05*diff)
    if q['id']=='cheap_priority':
        if v=='1':return 0
        return w*((4-d['price'])/3)*(int(v)-1)/2
    if q['id']=='long_trip_readiness':
        if v=='3':return w*0.35
        if v=='2':return w*(0.5 if d['distance']<=2 else -0.4)
        return w*(0.7 if d['distance']==1 else -0.75*(d['distance']-1))
    if q['id']=='unusual_climate':
        return w*(0.8 if ((d['climate'] in ('hot','tropical'))==(v=='yes')) else -0.3)
    if q['id']=='sea':
        return w*((1 if d['sea'] else -0.65) if v=='yes' else (0.45 if not d['sea'] else -0.15))
    if q['id']=='romantic':
        return w*(d['romance']/3 if v=='yes' else (0.2 if d['romance']<=2 else 0))
    if q['id']=='climate':
        climate_values={'moderate':1,'warm':2,'hot':3,'tropical':4}
        return w*(1-abs(climate_values[v]-climate_values[d['climate']])/3)
    if a in {'trip_length'}:return w*(1-abs(int(v)-d[a])/3)
    # Ординальные учебные экспертные оценки в диапазоне 1–3.
    return w*(1-abs(int(v)-d[a])/2)

def rank_destinations(answers):
    ds,qs,_=knowledge()
    items=[]
    for d in ds:
        fired=[]
        for q in qs:
            if q['id'] in answers:
                val=answers[q['id']]['value']
                pts=partial_score(q,val,d)
                fired.append({'rule':q['rule_id'],'text':q['text'],'score':round(pts,2),'origin':answers[q['id']]['origin']})
        score=round(sum(r['score'] for r in fired),2)
        positive=sorted([r for r in fired if r['score']>0],key=lambda v:-v['score'])[:3]
        items.append({'name':d['name'],'country':d['country'],'score':score,'styles':d['styles'],'price':d['price'],'climate':d['climate'],'sea':d['sea'], 'reasons':positive})
    items.sort(key=lambda x:(-x['score'],x['name']))
    for i,d in enumerate(items):d['rank']=i+1
    return items

def get_state(sid):
    ds,qs,pr=knowledge();answers=get_answers(sid)
    nq=next_question(answers,qs)
    return {'session_id':sid,'total_questions':len(qs),'answered':len(answers),'answered_by_user':sum(1 for a in answers.values() if a['origin']=='user'),
     'inferred': [{'id':k,'value':v['value']} for k,v in answers.items() if v['origin']=='rule'],
     'next_question':nq,'finished':nq is None,'top5':rank_destinations(answers)[:5] if answers else [],
     'all_results':rank_destinations(answers) if nq is None else [], 'answers':answers}

def inspect(kind):
    # Отдельные автономные БД доступны для просмотра (только таблицы из allowlist).
    allowed={'destinations':(KB_PATH,'destinations'),'questions':(KB_PATH,'questions'),'parameter_rules':(KB_PATH,'parameter_rules'),'sessions':(WORK_PATH,'sessions'),'answers':(WORK_PATH,'answers')}
    if kind not in allowed:raise ValueError('Неизвестная таблица')
    path,table=allowed[kind]
    with connection(path) as con:
        con.row_factory=sqlite3.Row
        rows=[dict(x) for x in con.execute(f'SELECT * FROM {table} ORDER BY rowid DESC LIMIT 100')]
        count=con.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]
    return {'table':table,'database':'knowledge.db' if path==KB_PATH else 'working.db','count':count,'rows':rows}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, format,*args):pass
    def respond(self, payload,code=200):
        data=json.dumps(payload,ensure_ascii=False).encode('utf-8')
        self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
    def do_GET(self):
        u=urlparse(self.path)
        if u.path=='/api/state':
            try:self.respond(get_state(parse_qs(u.query).get('sid',[''])[0]))
            except ValueError as e:self.respond({'error':str(e)},400)
            return
        if u.path=='/api/inspect':
            try:self.respond(inspect(parse_qs(u.query).get('kind',['destinations'])[0]))
            except ValueError as e:self.respond({'error':str(e)},400)
            return
        if u.path in ('/','/index.html','/style.css','/main.js'):
            f=STATIC/('index.html' if u.path=='/' else u.path.lstrip('/'))
            mime='text/html' if f.suffix=='.html' else ('text/css' if f.suffix=='.css' else 'text/javascript')
            b=f.read_bytes();self.send_response(200);self.send_header('Content-Type',mime+'; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
            return
        self.send_error(404)
    def do_POST(self):
        u=urlparse(self.path)
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n>3000:raise ValueError('Слишком длинный запрос')
            body=json.loads(self.rfile.read(n) or b'{}')
            if u.path=='/api/new':self.respond(get_state(start_session()))
            elif u.path=='/api/answer':self.respond(put_answer(str(body.get('session_id','')),str(body.get('question_id','')),str(body.get('value',''))))
            else:self.respond({'error':'Неизвестный путь'},404)
        except (ValueError,sqlite3.Error,json.JSONDecodeError) as e:self.respond({'error':str(e)},400)

def main():
    initialize()
    server=ThreadingHTTPServer((HOST,PORT),Handler)
    print(f'Экспертная система запущена: http://{HOST}:{PORT}',flush=True)
    print('Для остановки нажмите Ctrl+C',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()
